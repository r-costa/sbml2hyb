###Overview
sbml2hyb is written in Python and no additional Python module must be installed on your computer.

# SBML2HYB
## Overview
sbml2hyb is an stand-alone executable application for [SBML](https://synonym.caltech.edu/) compatible hybrid modelling. The tool is written in Python and can be used for converting between SBML format and HMOD (intermediate format — enabling communication between the essential components of the mechanistic and hybrid models). See [HMOD](https://github.com/rs-costa/sbml2hyb/blob/main/models/chassagnole1hyb.hmod) file example.

## Quick start guide
### Installation
- Users have two options to install sbml2hyb:
(i) A typical stand-alone executable Windows application; save the folder (nome link) on your computer and double-click the executable (.exe) file to open the tool.
(ii) Setup script to build and install sbml2hyb; run the following command via pip:
pip install -i https://test.pypi.org/simple/ sbml2hyb
- sbml2hyb is written in Python (requires version 3.8 or higher).
- Alternatively, you can clone this GitHub repository to a location on your computer's file system and then run sbml2hyb.py.
- 

### Package Dependencies
- tkinter 3.10.7  
- Pillow 9.0  
- libsbml 5.19.6 
- Python 3.8.2

### Usage
The users can use sbml2hyb either via the command line interface (SIM ??? codigo abaixo???) or via a graphical user interface (GUI) that allows to convert SBML files into HMOD files and vice versa. 
Once the simple Graphical User Interface (GUI) window opens, click the "Translate SBML" or "Translate HMOD" button, to find the SBML or HMOD file you want to convert, respectively.  After few seconds, the user get the final output in the panel of the GUI. The user can then save (click "export file" button) the final file (.xml or .hmod). The screenshot below illustrates the SBML input file of the tool before the conversion. You can view the SBML output (after export) for this example in a [separate file](link????).

![alt text](https://github.com/rs-costa/sbml2hyb/blob/main/source/prtsc_sbml2hyb.png?raw=true)

After installing out package the user can also simply create a python file with the following code:
import sbml2hyb as s
s.main()


## Developed at
- NOVA School of Science and Technology, Universidade NOVA de Lisboa (since 2021)

## License
This work is licensed under a <a href="https://www.gnu.org/licenses/gpl-3.0.html"> GNU Public License (version 3.0).</a>
